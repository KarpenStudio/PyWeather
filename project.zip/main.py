import tkinter as tk
from tkinter.messagebox import showinfo
import requests
from PIL import ImageTk, Image


def get_weather(city):
    weather_key = '6d7ec3e2ca4180a9e6293cc4c172fee7'  # Замените на ваш API ключ OpenWeatherMap
    url = 'https://api.openweathermap.org/data/2.5/weather'
    params = {'appid': weather_key, 'q': city, 'units': 'metric'}
    response = requests.get(url, params=params)
    weather_data = response.json()

    if weather_data['cod'] == 200:
        temperature = weather_data['main']['temp']
        weather_description = weather_data['weather'][0]['description']
        showinfo('Погода', f'Температура: {temperature} °C\n{weather_description}')
    else:
        showinfo('Ошибка', 'Не удалось получить данные о погоде')


def show_weather():
    city = city_entry.get()
    get_weather(city)


root = tk.Tk()
root.title('Погода')
root.geometry('250x150')

city_label = tk.Label(root, text='Город:')
city_label.pack()

city_entry = tk.Entry(root)
city_entry.pack()

show_button = tk.Button(root, text='Показать', command=show_weather)
show_button.pack()

root.mainloop()